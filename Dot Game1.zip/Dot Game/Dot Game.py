import pygame     # Imports the Pygame library used for creating games
import sys        # Provides access to system-specific parameters and functions
import random     # Provides functions for generating random numbers
import math       # Provides mathematical functions like square root and trigonometry
import os         # Provides a way to interact with the operating system

pygame.init()     # Initializes all the imported Pygame modules

# ERROR HANDLING
# If interpreter cannot detect, It will say error message.
try:
    # ---------------- Global Control Settings ----------------
    controls_settings = {
        "up": pygame.K_w,     # Sets 'W' key for moving up
        "down": pygame.K_s,   # Sets 'S' key for moving down
        "left": pygame.K_a,   # Sets 'A' key for moving left
        "right": pygame.K_d   # Sets 'D' key for moving right
    }

    # Opens the game in full-screen mode with the system's native resolution
    infoObject = pygame.display.Info()  # Gets information about the current display
    screen_width, screen_height = infoObject.current_w, infoObject.current_h  # Stores screen width and height
    screen = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN)  # Creates full-screen window
    pygame.display.set_caption("Dot Game")  # Sets the window title

    # ---------------- Colors and Fonts ----------------
    white   = (255, 255, 255)    # RGB value for white
    black   = (0, 0, 0)          # RGB value for black
    blue    = (0, 100, 255)      # RGB value for blue
    red     = (255, 0, 0)        # RGB value for red
    green   = (0, 255, 0)        # RGB value for green
    yellow  = (255, 255, 0)      # RGB value for yellow
    orange  = (255, 165, 0)      # RGB value for orange
    purple  = (128, 0, 128)      # RGB value for purple
    star_color = (0, 100, 255)   # RGB value for blue

    # Size of the game map (arena)
    arena_width, arena_height = 3000, 3000

    # Fonts
    title_font  = pygame.font.SysFont(None, 60)    # Font for menu titles
    button_font = pygame.font.SysFont(None, 40)    # Font for buttons and input text
    game_font   = pygame.font.SysFont(None, 35)    # Font for in-game text

    # ---------------- Helper Functions ----------------
    def distance(pos1, pos2):
        # Calculates the Euclidean distance between two positions
        return math.sqrt((pos1[0] - pos2[0])**2 + (pos1[1] - pos2[1])**2)

    def draw_text(text, font, color, surface, x, y):
        # Draws text centered at (x, y) on the given surface
        text_obj = font.render(text, True, color)
        text_rect = text_obj.get_rect(center=(x, y))
        surface.blit(text_obj, text_rect)

    def draw_button(text, font, center, width, height, text_color, button_color, border_color):
        # Draws a button with text at the specified center and size
        x, y = center
        rect = pygame.Rect(x - width // 2, y - height // 2, width, height)
        pygame.draw.rect(screen, button_color, rect)        # Draws button background
        pygame.draw.rect(screen, border_color, rect, 3)     # Draws button border
        text_obj = font.render(text, True, text_color)      # Renders the text
        text_rect = text_obj.get_rect(center=center)
        screen.blit(text_obj, text_rect)                    # Draws the text on the screen
        return rect                                         # Returns the button's rectangle for click detection

    def move_bot_towards_player(bot, player_pos):
        # Moves the bot towards the player's position using basic angle calculation
        angle = math.atan2(player_pos[1] - bot["y"], player_pos[0] - bot["x"])  # Calculates direction angle
        bot["x"] += math.cos(angle) * bot["speed"]  # Updates bot's x-position
        bot["y"] += math.sin(angle) * bot["speed"]  # Updates bot's y-position

    def wait_for_key_assignment(control_key):
        # Waits for the user to press a new key to reassign a control key
        clock = pygame.time.Clock()
        prompt_text = f"Press new key for {control_key.upper()}"
        while True:
            screen.fill(black)  # Clears the screen with black
            draw_text(prompt_text, title_font, white, screen, screen_width // 2, screen_height // 2)  # Shows prompt
            pygame.display.update()  # Updates the display
            for event in pygame.event.get():  # Handles events
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()  # Exits if the user closes the window
                elif event.type == pygame.KEYDOWN:
                    return event.key  # Returns the pressed key as the new assignment
            clock.tick(60)  # Limits the loop to 60 frames per second

    # ---------------- Function: Settings Menu (Key Remapping) ----------------
    def settings_menu():
        clock = pygame.time.Clock()  # Creates a clock to control frame rate
        waiting = True  # Controls the loop
        while waiting:
            screen.fill(black)  # Clears the screen with black
            draw_text("Settings", title_font, white, screen, screen_width // 2, 40)  # Draws the "Settings" title
            draw_text("Controls", button_font, white, screen, screen_width // 2, 100)  # Draws "Controls" subtitle

            # List of control labels and their corresponding keys
            controls_list = [("Up", "up"), ("Down", "down"), ("Left", "left"), ("Right", "right")]
            start_y = 200      # Starting Y-position for the controls
            spacing_y = 140    # Vertical space between control items
            control_rects = {} # Dictionary to store clickable areas for each control

            for index, (label, key_name) in enumerate(controls_list):
                current_key = controls_settings[key_name]  # Gets the current key binding
                key_name_str = pygame.key.name(current_key).upper()  # Converts key code to string
                draw_text(f"{label}:", game_font, white, screen, screen_width // 4, start_y + index * spacing_y)  # Draws the label

                square_size = 60  # Size of the square displaying the key
                square_x = (screen_width * 3) // 4 - square_size // 2
                square_y = start_y + index * spacing_y - square_size // 2
                square_rect = pygame.Rect(square_x, square_y, square_size, square_size)  # Creates the square area
                pygame.draw.rect(screen, white, square_rect, 2)  # Draws the square border
                draw_text(key_name_str, game_font, white, screen, square_rect.centerx, square_rect.centery)  # Draws the key text
                control_rects[key_name] = square_rect  # Stores the square for input detection

            # Draws the "Back" button at the bottom
            back_button = draw_button("Back", button_font, (screen_width // 2, screen_height - 60), 200, 50, white, black, white)

            pygame.display.update()  # Updates the display

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()  # Exits the game if window is closed
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()  # Gets the current mouse position
                    for key_name, rect in control_rects.items():
                        if rect.collidepoint(mouse_pos):  # Checks if a control square is clicked
                            new_key = wait_for_key_assignment(key_name)  # Waits for new key input
                            if new_key is not None:
                                controls_settings[key_name] = new_key  # Updates the key binding
                    if back_button.collidepoint(mouse_pos):  # Checks if "Back" button is clicked
                        waiting = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:  # Exits the settings menu if ESC is pressed
                        waiting = False
            clock.tick(60)  # Limits the loop to 60 FPS

    # ---------------- Function: Pause Menu ----------------
    def pause_menu():
        paused = True   # Controls the pause menu loop
        choice = None   # Stores the selected option

        # Creates a semi-transparent overlay
        overlay = pygame.Surface((screen_width, screen_height))
        overlay.set_alpha(128)  # Makes the overlay partially transparent
        overlay.fill(black)     # Fills the overlay with black

        clock = pygame.time.Clock()
        while paused:
            screen.blit(overlay, (0, 0))  # Draws the overlay on the screen

            # Draws the title and buttons
            draw_text("Paused", title_font, white, screen, screen_width // 2, screen_height // 2 - 150)
            resume_button = draw_button("Resume", button_font, (screen_width // 2, screen_height // 2 - 80), 200, 50, white, black, white)
            settings_button = draw_button("Settings", button_font, (screen_width // 2, screen_height // 2 - 10), 200, 50, white, black, white)
            main_menu_button = draw_button("Main Menu", button_font, (screen_width // 2, screen_height // 2 + 60), 200, 50, white, black, white)
            quit_button = draw_button("Quit Game", button_font, (screen_width // 2, screen_height // 2 + 140), 200, 50, white, black, white)

            pygame.display.update()  # Updates the screen

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()  # Exits the game if window is closed
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:  # Resumes the game if ESC is pressed
                        choice = "resume"
                        paused = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if resume_button.collidepoint(mouse_pos):  # Resumes the game
                        choice = "resume"
                        paused = False
                    elif settings_button.collidepoint(mouse_pos):  # Opens the settings menu
                        settings_menu()
                    elif main_menu_button.collidepoint(mouse_pos):  # Goes to the main menu
                        choice = "main_menu"
                        paused = False
                    elif quit_button.collidepoint(mouse_pos):  # Quits the game
                        choice = "quit"
                        paused = False

            clock.tick(60)  # Limits the loop to 60 FPS

        return choice  # Returns the selected option from pause menu


     # ---------------- Function: Save Score ----------------
    def save_score(username, score):
        
        # Opens the score history file in append mode and writes the username and score
        with open("score_history.txt", "a") as f:
            f.write(f"{username},{score}\n")

    # ---------------- New Function: Delete Score History ----------------
    def delete_score_history():
        
        # If the score history file exists, overwrite it with an empty string (clears all data)
        if os.path.exists("score_history.txt"):
            with open("score_history.txt", "w") as f:
                f.write("")

    # ---------------- Function: Game Over Menu (English) ----------------
    def game_over_menu(username, player_color, final_score):
        clock = pygame.time.Clock()
        while True:
            screen.fill(black)  # Clears the screen
            draw_text("Game Over!", title_font, white, screen, screen_width // 2, screen_height // 4)  # Title
            draw_text("Final Score: " + str(final_score), game_font, white, screen, screen_width // 2, screen_height // 4 + 50)  # Final score

            # Draw buttons for user options
            play_again_button = draw_button("Play Again", button_font, (screen_width // 2, screen_height // 2 - 40), 200, 50, white, black, white)
            main_menu_button = draw_button("Main Menu", button_font, (screen_width // 2, screen_height // 2 + 30), 200, 50, white, black, white)
            quit_button = draw_button("Quit Game", button_font, (screen_width // 2, screen_height // 2 + 100), 200, 50, white, black, white)

            pygame.display.update()  # Updates the display

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()  # Exits the game if the window is closed
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if play_again_button.collidepoint(mouse_pos):
                        game_loop(username, player_color)  # Starts a new game with same user and color
                        return
                    elif main_menu_button.collidepoint(mouse_pos):
                        menu()  # Goes back to the main menu
                        return
                    elif quit_button.collidepoint(mouse_pos):
                        pygame.quit(); sys.exit()  # Quits the game
                        
            clock.tick(60)  # Limits the frame rate to 60 FPS

    # ---------------- Function: Player Scores Menu ----------------
    def player_scores_menu(player_name, sorted_scores):
        clock = pygame.time.Clock()

        # Filters the scores to only include those matching the player's name exactly
        matching_scores = [entry for entry in sorted_scores if entry[0] == player_name]

        while True:
            screen.fill(black)  # Clears the screen

            # Draws the title
            draw_text(f"Scores for {player_name}", title_font, white, screen, screen_width // 2, 50)

            if matching_scores:
                y_start = 120  # Starting Y-position
                for idx, entry in enumerate(matching_scores):
                    entry_text = f"{entry[0]}: {entry[1]}"  # Format: "Name: Score"
                    draw_text(entry_text, game_font, white, screen, screen_width // 2, y_start + idx * 30)
            else:
                draw_text("No scores found for that player.", game_font, red, screen, screen_width // 2, 120)

            # Draws the "Back" button
            back_button = draw_button("Back", button_font, (screen_width // 2, screen_height - 50), 200, 50, white, black, white)

            pygame.display.update()  # Updates the screen

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()  # Exits if the window is closed
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if back_button.collidepoint(mouse_pos):  # Returns to the previous menu
                        return
            clock.tick(60)  # Limits frame rate to 60 FPS
            
    # SEARCH ALGORITHM
    # ---------------- Function: Score History Menu (with Searching & Delete) ----------------
    def score_history_menu():
        clock = pygame.time.Clock()

        # Read scores from file if it exists
        if os.path.exists("score_history.txt"):
            with open("score_history.txt", "r") as f:
                lines = f.readlines()
            score_list = []
            for line in lines:
                line = line.strip()
                if line:
                    parts = line.split(",")
                    if len(parts) == 2:
                        try:
                            score_value = int(parts[1])  # Try to convert score to integer
                        except:
                            score_value = 0  # If conversion fails, use 0
                        score_list.append((parts[0], score_value))
        else:
            score_list = []

        # Sort the scores in ascending order
        sorted_scores = sorted(score_list, key=lambda x: x[1])
        highest_score = sorted_scores[-1][1] if sorted_scores else 0  # Get the highest score

        search_box = ""      # Text input for searching
        search_result = None # Store result of search (index or None)

        # Binary search for numerical score search
        def binary_search_scores(scores, target):
            low = 0
            high = len(scores) - 1
            while low <= high:
                mid = (low + high) // 2
                if scores[mid][1] == target:
                    return mid
                elif scores[mid][1] < target:
                    low = mid + 1
                else:
                    high = mid - 1
            return -1  # Not found

        while True:
            screen.fill(black)
            draw_text("Score History", title_font, white, screen, screen_width // 2, 50)
            draw_text("Highest Score: " + str(highest_score), game_font, white, screen, screen_width // 2, 100)
            draw_text("Enter score or player name to search:", game_font, white, screen, screen_width // 2, 140)

            # Draw search box
            search_box_rect = pygame.Rect(screen_width // 2 - 150, 160, 300, 40)
            pygame.draw.rect(screen, white, search_box_rect, 2)
            search_surface = game_font.render(search_box, True, white)
            screen.blit(search_surface, (search_box_rect.x + 5, search_box_rect.y + 5))

            # Show search result
            if search_result is not None:
                if search_result == -1:
                    draw_text("Score not found.", game_font, red, screen, screen_width // 2, 210)
                else:
                    found_entry = sorted_scores[search_result]
                    draw_text(f"Found: {found_entry[0]} with score {found_entry[1]}", game_font, green, screen, screen_width // 2, 210)

            # Display all scores (sorted)
            y_start = 250
            for idx, entry in enumerate(sorted_scores):
                entry_text = f"{entry[0]}: {entry[1]}"
                draw_text(entry_text, game_font, white, screen, screen_width // 2, y_start + idx * 30)

            # Draw "Delete History" and "Back" buttons
            delete_button = draw_button("Delete History", button_font, (screen_width // 2, screen_height - 100), 200, 50, white, black, white)
            back_button = draw_button("Back", button_font, (screen_width // 2, screen_height - 50), 200, 50, white, black, white)

            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        search_box = search_box[:-1]  # Remove last character
                    elif event.key == pygame.K_RETURN:
                        # If input is numeric, do a binary search
                        try:
                            target = int(search_box.strip())
                            search_result = binary_search_scores(sorted_scores, target)
                        except ValueError:
                            # Otherwise, treat it as player name and open their scores
                            player_scores_menu(search_box.strip(), sorted_scores)
                            search_box = ""
                            search_result = None
                    else:
                        search_box += event.unicode  # Add typed character
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if delete_button.collidepoint(mouse_pos):
                        delete_score_history()  # Clear file contents
                        # Clear score list and reset variables
                        sorted_scores = []
                        highest_score = 0
                        search_box = ""
                        search_result = None
                    elif back_button.collidepoint(mouse_pos):
                        return  # Go back to previous menu
                    
            clock.tick(60)

    # ---------------- Function: Get User Settings (Username & Character Color) ----------------
    
    # This function displays a screen where the user can enter a username and select a character color.
    def get_user_settings():
        user_name = "" # Stores the username entered by the player.
        chosen_color = None # Stores the color chosen by the player.
        clock = pygame.time.Clock() # Sets up a clock to manage the frame rate.
        
        while True:
            screen.fill(black) # Clears the screen with a black background.
            
            # Displays the prompt for entering the username.
            draw_text("Enter your username:", button_font, white, screen, screen_width // 2, screen_height // 4)
            
            # Creates a rectangle for the username input box.
            input_box_rect = pygame.Rect(screen_width // 2 - 150, screen_height // 4 + 40, 300, 50)
            pygame.draw.rect(screen, white, input_box_rect, 2)
            
            # Renders the current username text and displays it inside the box.
            username_surface = button_font.render(user_name, True, white)
            screen.blit(username_surface, (input_box_rect.x + 10, input_box_rect.y + 10))
            
            # Displays the prompt to choose a character color.
            draw_text("Select your character color:", button_font, white, screen, screen_width // 2, screen_height // 4 + 120)
            
            # Defines a list of available character colors.
            available_colors = [
                ("Blue", blue),
                ("Red", red),
                ("Green", green),
                ("Yellow", yellow),
                ("Purple", purple),
                ("Orange", orange),
                ("Cyan", (0, 255, 255)),
                ("Magenta", (255, 0, 255)),
                ("Pink", (255, 192, 203)),
                ("Teal", (0, 128, 128))
            ]
            
            color_buttons = [] # Will store the button rectangles and colors.
            spacing = 70 # Distance between color buttons.
            total_width = len(available_colors) * 60 + (len(available_colors) - 1) * 10
            start_x = screen_width // 2 - total_width // 2
            y_pos = screen_height // 4 + 160
            
            # Creates and displays buttons for each available color.
            for i, (name, color_val) in enumerate(available_colors):
                btn_rect = pygame.Rect(start_x + i * spacing, y_pos, 60, 60)
                pygame.draw.rect(screen, color_val, btn_rect) # Draws the color-filled button.
                if chosen_color == color_val:
                    pygame.draw.rect(screen, white, btn_rect, 3) # Highlights the selected color.
                else:
                    pygame.draw.rect(screen, white, btn_rect, 1)
                color_buttons.append((btn_rect, color_val))
            
            start_button_rect = None
            
            # If both username and color are provided, draw the "Start Game" button.
            if user_name.strip() != "" and chosen_color is not None:
                start_button_rect = draw_button("Start Game", button_font, 
                                                (screen_width // 2, screen_height // 4 + 250), 
                                                200, 50, white, black, white)
            
            pygame.display.update() # Updates the screen with the new drawings.
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit() # Exits the game if the window is closed.
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        # If enter is pressed and all fields are valid, return the data.
                        if user_name.strip() != "" and chosen_color is not None:
                            return user_name, chosen_color
                    elif event.key == pygame.K_BACKSPACE:
                        user_name = user_name[:-1] # Deletes the last character.
                    else:
                        user_name += event.unicode # Adds the typed character.
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    # Checks if a color button was clicked.
                    for btn_rect, color_val in color_buttons:
                        if btn_rect.collidepoint(mouse_pos):
                            chosen_color = color_val
                    # If "Start Game" button is clicked, return the settings.
                    if start_button_rect is not None and start_button_rect.collidepoint(mouse_pos):
                        return user_name, chosen_color
                    
            clock.tick(60) # Limits the loop to 60 frames per second.

    # ---------------- Function: Main Menu ----------------
    
    # FILE HANDLING
    # This global variable ensures music only plays once.
    music_played = False

    # This function randomly selects and plays a music file from the 'music' directory.
    def play_random_music():
        global music_played # Refers to the global music flag.
        
        if music_played:
            return # Do not play again if music is already playing.
        
        current_directory = os.path.dirname(os.path.realpath(__file__))
        music_directory = os.path.join(current_directory, 'music')
        
        # Find music files
        music_files = [f for f in os.listdir(music_directory) if f.endswith('.wav')]
        
        if not music_files:
            print("Music file cannot find.")
            return
        
        # Chooses a random music file and plays it in a loop.
        sound_file = os.path.join(music_directory, random.choice(music_files))
        pygame.mixer.music.load(sound_file)
        pygame.mixer.music.play(-1) # -1 means loop indefinitely.
        
        music_played = True # Marks that music is already playing.

    # Menu function
    # This function displays the main menu with background animation and clickable buttons.
    def menu():
        global music_played  # Uses the global flag to control music.

        menu_bg_circles = [] # Stores background decorative circles.
        colors_bg = [orange, green, blue, purple, yellow, red]
        # Randomly generates 20 colorful circles for visual effect.
        for i in range(20):
            pos = (random.randint(0, screen_width), random.randint(0, screen_height))
            radius = random.randint(10, 50)
            col = random.choice(colors_bg)
            menu_bg_circles.append({"pos": pos, "radius": radius, "color": col})

        title_text = "Dot Game"
        title_obj = title_font.render(title_text, True, white)
        title_rect = title_obj.get_rect(center=(screen_width // 2, screen_height // 4))

        play_random_music() # Starts background music (only once).

        circle_radius = 15
        circle_x = title_rect.left - circle_radius - 20
        circle_y = title_rect.centery
        clock = pygame.time.Clock()

        while True:
            screen.fill(black) # Clears the screen.
            # Draws the colorful background circles.
            for circle in menu_bg_circles:
                pygame.draw.circle(screen, circle["color"], circle["pos"], circle["radius"])
            screen.blit(title_obj, title_rect) # Draws the game title.
            pygame.draw.circle(screen, green, (circle_x, circle_y), circle_radius) # Draws a small green circle.

            # Start Game, Settings, Score History and Quit Game buttons.
            # Creates the menu buttons.
            start_button_rect = draw_button("Start Game", button_font, (screen_width // 2, screen_height // 2 - 140), 200, 50, white, black, white)
            settings_button_rect = draw_button("Settings", button_font, (screen_width // 2, screen_height // 2 - 60), 200, 50, white, black, white)
            score_history_button_rect = draw_button("Score History", button_font, (screen_width // 2, screen_height // 2 + 20), 200, 50, white, black, white)
            quit_button_rect = draw_button("Quit Game", button_font, (screen_width // 2, screen_height // 2 + 100), 200, 50, white, black, white)

            # Displays the version number in the bottom-right corner.
            draw_text("Version 30.0", game_font, white, screen, screen_width - 80, screen_height - 20)
            pygame.display.update() # Updates the screen.

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit() # Quits the game.
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if start_button_rect.collidepoint(mouse_pos):
                        pygame.mixer.music.stop()  # Stops music.
                        username, player_color = get_user_settings() # Gets user settings.
                        game_loop(username, player_color) # Starts the game.
                    elif settings_button_rect.collidepoint(mouse_pos):
                        pygame.mixer.music.stop()
                        settings_menu() # Opens settings menu.
                    elif score_history_button_rect.collidepoint(mouse_pos):
                        pygame.mixer.music.stop()
                        score_history_menu() # Opens score history.
                    elif quit_button_rect.collidepoint(mouse_pos):
                        pygame.quit()
                        sys.exit() # Exits the game.

            clock.tick(60) # Limits to 60 FPS.

    # ---------------- Function: Game Loop ----------------
    def game_loop(username, player_color):
        
        # Set initial player position in the center of the arena
        player_pos = [arena_width // 2, arena_height // 2]
        player_radius = 20 # Initial size of the player
        player_speed = 8 # Player movement speed
        score = 0  # Initial score is 0
        
        # Food settings
        food_count = 200
        food_radius = 5
        food_list = []
        
        # Generate food items at random positions
        for i in range(food_count):
            x = random.randint(0, arena_width)
            y = random.randint(0, arena_height)
            food_list.append([x, y])
            
        # Bot settings
        bot_count = 1
        bots = []
        for i in range(bot_count):
            bot_x = random.randint(0, arena_width)
            bot_y = random.randint(0, arena_height)
            bot_radius = random.randint(40, 100)
            bot_speed = random.uniform(1.5, 4)
            bot_color = (random.randint(0,255), random.randint(0,255), random.randint(0,255))
            bots.append({
                "x": bot_x,
                "y": bot_y,
                "radius": bot_radius,
                "speed": bot_speed,
                "behavior": "aggressive",
                "color": bot_color
            })
            
        # Initialize the snake enemy
        snake = initialize_snake(player_pos)
        
        # Star settings (collectibles that end the game)
        star_count = 5
        stars = []
        for i in range(star_count):
            star_x = random.randint(0, arena_width)
            star_y = random.randint(0, arena_height)
            stars.append((star_x, star_y))
        star_outer_radius = 45
        star_inner_radius = 21
        
        # Camera follows the player
        camera_x = player_pos[0] - screen_width // 2
        camera_y = player_pos[1] - screen_height // 2
        
        # Create a clock to control the frame rate
        clock = pygame.time.Clock()
        
        # ---------------- Game Loop Starts ----------------
        while True:
            screen.fill(black)  # Clear the screen with black background
            
            # Handle events like quit or pause
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    selection = pause_menu()
                    if selection == "main_menu":
                        menu()
                        return
                    elif selection == "quit":
                        pygame.quit(); sys.exit()
                        
            # Player movement input
            keys = pygame.key.get_pressed()
            dx = dy = 0
            if keys[controls_settings["up"]]:
                dy -= player_speed
            if keys[controls_settings["down"]]:
                dy += player_speed
            if keys[controls_settings["left"]]:
                dx -= player_speed
            if keys[controls_settings["right"]]:
                dx += player_speed
                
            # Update player position
            player_pos[0] += dx
            player_pos[1] += dy
            
            # Prevent player from going outside the arena
            player_pos[0] = max(player_radius, min(arena_width - player_radius, player_pos[0]))
            player_pos[1] = max(player_radius, min(arena_height - player_radius, player_pos[1]))
            
            # Update camera position based on player
            camera_x = player_pos[0] - screen_width // 2
            camera_y = player_pos[1] - screen_height // 2
            
            # ----------- Draw and Handle Food -----------
            for food in food_list:
                pygame.draw.circle(screen, yellow, (food[0] - camera_x, food[1] - camera_y), food_radius)
            new_food_list = []
            for food in food_list:
                if distance(player_pos, food) < player_radius + food_radius:
                    player_radius += 1
                    score += 1
                else:
                    new_food_list.append(food)
            food_list = new_food_list
            
            # ----------- Draw and Handle Bots -----------
            for bot in bots[:]:
                pygame.draw.circle(screen, bot["color"], (int(bot["x"]) - camera_x, int(bot["y"]) - camera_y), bot["radius"])
                if bot["behavior"] == "aggressive":
                    move_bot_towards_player(bot, player_pos)
                    
                # Make sure bot stays within arena
                bot["x"] = max(bot["radius"], min(arena_width - bot["radius"], bot["x"]))
                bot["y"] = max(bot["radius"], min(arena_height - bot["radius"], bot["y"]))
                
                # Collision detection with player
                if distance(player_pos, (bot["x"], bot["y"])) < player_radius + bot["radius"]:
                    if player_radius > bot["radius"]:
                        player_radius -= bot["radius"] // 2  # Shrink player after eating the bot
                        score += 50  # Earn 50 points for defeating a bot
                        bots.remove(bot) # Remove defeated bot
                        
                        # Spawn a new bot with random stats
                        new_bot_radius = random.randint(player_radius + 1, player_radius + 50)
                        new_bot_x = random.randint(0, arena_width)
                        new_bot_y = random.randint(0, arena_height)
                        new_bot_speed = random.uniform(1.5, 4)
                        new_bot_color = (random.randint(0,255), random.randint(0,255), random.randint(0,255))
                        bots.append({
                            "x": new_bot_x,
                            "y": new_bot_y,
                            "radius": new_bot_radius,
                            "speed": new_bot_speed,
                            "behavior": "aggressive",
                            "color": new_bot_color
                        })
                    else:
                        
                        # Player is eaten by bot → game over
                        save_score(username, score)
                        game_over_menu(username, player_color, score)
                        return

            # ----------- Handle Snake Collision -----------
            snake = update_snake(snake, player_pos)
            draw_snake(snake, camera_x, camera_y)
            if distance(snake["segments"][0], player_pos) < (player_radius + snake["segment_size"]):
                save_score(username, score)
                game_over_menu(username, player_color, score)
                return
            
            # ----------- Draw and Handle Stars -----------
            for star in stars:
                star_screen = (int(star[0]-camera_x), int(star[1]-camera_y))
                draw_star(screen, star_color, star_screen, star_outer_radius, star_inner_radius)
                if distance(player_pos, star) < (player_radius + star_outer_radius):
                    save_score(username, score)
                    game_over_menu(username, player_color, score)
                    return
                
            # Draw the player
            pygame.draw.circle(screen, player_color, (player_pos[0] - camera_x, player_pos[1] - camera_y), player_radius)
            
            # Draw username above the player
            draw_text(username, game_font, white, screen, player_pos[0] - camera_x, player_pos[1] - camera_y - player_radius - 20)
            
            # Draw score at top-left
            draw_text("Score: " + str(score), game_font, white, screen, 100, 30)
            
            # Update display
            pygame.display.update()
            clock.tick(60)

    # ---------------- Draw Star Function ----------------
    def draw_star(surface, color, center, outer_radius, inner_radius):
        cx, cy = center
        points = []
        for i in range(10):
            angle = math.radians(i * 36 - 90) # 36° step, starting from top (-90°)
            r = outer_radius if i % 2 == 0 else inner_radius
            x = cx + r * math.cos(angle)
            y = cy + r * math.sin(angle)
            points.append((x, y))
        pygame.draw.polygon(surface, color, points)

    # ---------------- Snake Enemy Functions ----------------
    
    # Initializes the snake enemy with a starting position and certain attributes.
    def initialize_snake(player_pos):
        snake = {
            "segments": [], # List of segments representing the snake's body.
            "speed": 3, # Speed at which the snake moves.
            "segment_size": 20, # Size of each segment of the snake.
            "detection_range": 300, # Range within which the snake will detect the player.
            "length": 15 # Initial length of the snake.
        }
        snake_x = random.randint(0, arena_width) # Randomly choose x-coordinate for the snake.
        snake_y = random.randint(0, arena_height) # Randomly choose y-coordinate for the snake.
        
        # Ensure the snake is far enough from the player.
        while distance((snake_x, snake_y), player_pos) < 400:
            snake_x = random.randint(0, arena_width)
            snake_y = random.randint(0, arena_height)
        segment_spacing = 25 # Distance between segments.
        
        # Create snake's body segments starting from the head.
        snake["segments"] = [(snake_x - i * segment_spacing, snake_y) for i in range(snake["length"])]
        return snake
    
    # Updates the snake's position based on the player's position.
    def update_snake(snake, player_pos):
        head = snake["segments"][0] # Get the snake's head.
        
        # If the snake is within its detection range of the player, it will move towards the player.
        if distance(head, player_pos) < snake["detection_range"]:
            angle = math.atan2(player_pos[1]-head[1], player_pos[0]-head[0]) # Calculate angle towards player.
            new_head = (head[0] + snake["speed"]*math.cos(angle), # Move the head.
                        head[1] + snake["speed"]*math.sin(angle))
            snake["segments"][0] = new_head # Update head position.
            segment_spacing = 25 # Distance between segments.
            
            # Update the positions of all body segments to follow the head.
            for i in range(1, len(snake["segments"])):
                prev_seg = snake["segments"][i-1] # Previous segment.
                curr_seg = snake["segments"][i] # Current segment.
                dx = prev_seg[0] - curr_seg[0] # Change in x position.
                dy = prev_seg[1] - curr_seg[1] # Change in y position.
                dist_val = math.sqrt(dx*dx + dy*dy) # Distance between the two segments.
                if dist_val != 0: # Avoid division by zero.
                    new_pos = (prev_seg[0] - (dx/dist_val)*segment_spacing,
                            prev_seg[1] - (dy/dist_val)*segment_spacing)
                    snake["segments"][i] = new_pos # Update the current segment position.
        return snake
    
    # Draws the snake on the screen.
    def draw_snake(snake, camera_x, camera_y):
        snake_color = (34, 139, 34)  # The color of the snake (forest green).
        head = snake["segments"][0] # Get the head segment of the snake.
        head_screen = (int(head[0]-camera_x), int(head[1]-camera_y)) # Adjust for camera position.
        pygame.draw.circle(screen, snake_color, head_screen, snake["segment_size"]) # Draw the head.
        
        # Eyes
        # Draw eyes on the snake's head.
        eye_radius = 3 # Size of the eyes.
        eye_offset_x = snake["segment_size"]//2 - eye_radius # X offset for eye placement.
        eye_offset_y = -snake["segment_size"]//3 # Y offset for eye placement.
        left_eye = (head_screen[0]-eye_offset_x, head_screen[1]+eye_offset_y) # Left eye position.
        right_eye = (head_screen[0]+eye_offset_x, head_screen[1]+eye_offset_y) # Right eye position.
        pygame.draw.circle(screen, white, left_eye, eye_radius) # Draw left eye.
        pygame.draw.circle(screen, white, right_eye, eye_radius) # Draw right eye.
        
        # Smiling mouth
        # Draw a smiling mouth.
        mouth_rect = pygame.Rect(0, 0, snake["segment_size"]*1.2, snake["segment_size"]*1.2) # Mouth size.
        mouth_rect.center = head_screen # Set mouth position at the head center.
        start_arc = math.radians(210) # Start angle for the arc.
        end_arc = math.radians(330) # End angle for the arc.
        pygame.draw.arc(screen, white, mouth_rect, start_arc, end_arc, 2) # Draw the smile.
        
        # Draw the body segments of the snake (excluding the head).
        for seg in snake["segments"][1:]:
            pos = (int(seg[0]-camera_x), int(seg[1]-camera_y))
            pygame.draw.circle(screen, snake_color, pos, snake["segment_size"])

    # ---------------- Program Start ----------------
    menu() # Start the game by displaying the menu.

# If interpreter cannot detect, It will say error message.
except Exception as e:
    print("Code gives error and interpreter cannot detect.")