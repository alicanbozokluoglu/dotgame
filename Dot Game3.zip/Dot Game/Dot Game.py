 + idx * 30)

            # Draw "Delete History" and "Back" buttons
            delete_button = draw_button("Delete History", button_font, (screen_width // 2, screen_height - 100), 200, 50, white, black, white)
            back_button = draw_button("Back", button_font, (screen_width // 2, screen_height - 50), 200, 50, white, black, white)

            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        search_box = search_box[:-1]  # Remove last character
                    elif event.key == pygame.K_RETURN:
                        # If input is numeric, do a binary search
                        try:
                            target = int(search_box.strip())
                            search_result = binary_search_scores(sorted_scores, target)
                        except ValueError:
                            # Otherwise, treat it as player name and open their scores
                            player_scores_menu(search_box.strip(), sorted_scores)
                            search_box = ""
                            search_result = None
                    else:
                        search_box += event.unicode  # Add typed character
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if delete_button.collidepoint(mouse_pos):
                        delete_score_history()  # Clear file contents
                        # Clear score list and reset variables
                        sorted_scores = []
                        highest_score = 0
                        search_box = ""
                        search_result = None
                    elif back_button.collidepoint(mouse_pos):
                        return  # Go back to previous menu
                    
            clock.tick(60)

    # ---------------- Function: Get User Settings (Username & Character Color) ----------------
    
    # This function displays a screen where the user can enter a username and select a character color.
    def get_user_settings():
        user_name = "" # Stores the username entered by the player.
        chosen_color = None # Stores the color chosen by the player.
        clock = pygame.time.Clock() # Sets up a clock to manage the frame rate.
        
        while True:
            screen.fill(black) # Clears the screen with a black background.
            
            # Displays the prompt for entering the username.
            draw_text("Enter your username:", button_font, white, screen, screen_width // 2, screen_height // 4)
            
            # Creates a rectangle for the username input box.
            input_box_rect = pygame.Rect(screen_width // 2 - 150, screen_height // 4 + 40, 300, 50)
            pygame.draw.rect(screen, white, input_box_rect, 2)
            
            # Renders the current username text and displays it inside the box.
            username_surface = button_font.render(user_name, True, white)
            screen.blit(username_surface, (input_box_rect.x + 10, input_box_rect.y + 10))
            
            # Displays the prompt to choose a character color.
            draw_text("Select your character color:", button_font, white, screen, screen_width // 2, screen_height // 4 + 120)
            
            # Defines a list of available character colors.
            available_colors = [
                ("Blue", blue),
                ("Red", red),
                ("Green", green),
                ("Yellow", yellow),
                ("Purple", purple),
                ("Orange", orange),
                ("Cyan", (0, 255, 255)),
                ("Magenta", (255, 0, 255)),
                ("Pink", (255, 192, 203)),
                ("Teal", (0, 128, 128))
            ]
            
            color_buttons = [] # Will store the button rectangles and colors.
            spacing = 70 # Distance between color buttons.
            total_width = len(available_colors) * 60 + (len(available_colors) - 1) * 10
            start_x = screen_width // 2 - total_width // 2
            y_pos = screen_height // 4 + 160
            
            # Creates and displays buttons for each available color.
            for i, (name, color_val) in enumerate(available_colors):
                btn_rect = pygame.Rect(start_x + i * spacing, y_pos, 60, 60)
                pygame.draw.rect(screen, color_val, btn_rect) # Draws the color-filled button.
                if chosen_color == color_val:
                    pygame.draw.rect(screen, white, btn_rect, 3) # Highlights the selected color.
                else:
                    pygame.draw.rect(screen, white, btn_rect, 1)
                color_buttons.append((btn_rect, color_val))
            
            start_button_rect = None
            
            # If both username and color are provided, draw the "Start Game" button.
            if user_name.strip() != "" and chosen_color is not None:
                start_button_rect = draw_button("Start Game", button_font, 
                                                (screen_width // 2, screen_height // 4 + 250), 
                                                200, 50, white, black, white)
            
            pygame.display.update() # Updates the screen with the new drawings.
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit() # Exits the game if the window is closed.
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        # If enter is pressed and all fields are valid, return the data.
                        if user_name.strip() != "" and chosen_color is not None:
                            return user_name, chosen_color
                    elif event.key == pygame.K_BACKSPACE:
                        user_name = user_name[:-1] # Deletes the last character.
                    else:
                        user_name += event.unicode # Adds the typed character.
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    # Checks if a color button was clicked.
                    for btn_rect, color_val in color_buttons:
                        if btn_rect.collidepoint(mouse_pos):
                            chosen_color = color_val
                    # If "Start Game" button is clicked, return the settings.
                    if start_button_rect is not None and start_button_rect.collidepoint(mouse_pos):
                        return user_name, chosen_color
                    
            clock.tick(60) # Limits the loop to 60 frames per second.

    # ---------------- Function: Main Menu ----------------
    
    # FILE HANDLING
    # This global variable ensures music only plays once.
    music_played = False

    # This function randomly selects and plays a music file from the 'music' directory.
    def play_random_music():
        global music_played # Refers to the global music flag.
        
        if music_played:
            return # Do not play again if music is already playing.
        
        current_directory = os.path.dirname(os.path.realpath(__file__))
        music_directory = os.path.join(current_directory, 'music')
        
        # Find music files
        music_files = [f for f in os.listdir(music_directory) if f.endswith('.wav')]
        
        if not music_files:
            print("Music file cannot find.")
            return
        
        # Chooses a random music file and plays it in a loop.
        sound_file = os.path.join(music_directory, random.choice(music_files))
        pygame.mixer.music.load(sound_file)
        pygame.mixer.music.play(-1) # -1 means loop indefinitely.
        
        music_played = True # Marks that music is already playing.

    # Menu function
    # This function displays the main menu with background animation and clickable buttons.
    def menu():
        global music_played  # Uses the global flag to control music.

        menu_bg_circles = [] # Stores background decorative circles.
        colors_bg = [orange, green, blue, purple, yellow, red]
        # Randomly generates 20 colorful circles for visual effect.
        for i in range(20):
            pos = (random.randint(0, screen_width), random.randint(0, screen_height))
            radius = random.randint(10, 50)
            col = random.choice(colors_bg)
            menu_bg_circles.append({"pos": pos, "radius": radius, "color": col})

        title_text = "Dot Game"
        title_obj = title_font.render(title_text, True, white)
        title_rect = title_obj.get_rect(center=(screen_width // 2, screen_height // 4))

        play_random_music() # Starts background music (only once).

        circle_radius = 15
        circle_x = title_rect.left - circle_radius - 20
        circle_y = title_rect.centery
        clock = pygame.time.Clock()

        while True:
            screen.fill(black) # Clears the screen.
            # Draws the colorful background circles.
            for circle in menu_bg_circles:
                pygame.draw.circle(screen, circle["color"], circle["pos"], circle["radius"])
            screen.blit(title_obj, title_rect) # Draws the game title.
            pygame.draw.circle(screen, green, (circle_x, circle_y), circle_radius) # Draws a small green circle.

            # Start Game, Settings, Score History and Quit Game buttons.
            # Creates the menu buttons.
            start_button_rect = draw_button("Start Game", button_font, (screen_width // 2, screen_height // 2 - 140), 200, 50, white, black, white)
            settings_button_rect = draw_button("Settings", button_font, (screen_width // 2, screen_height // 2 - 60), 200, 50, white, black, white)
            score_history_button_rect = draw_button("Score History", button_font, (screen_width // 2, screen_height // 2 + 20), 200, 50, white, black, white)
            quit_button_rect = draw_button("Quit Game", button_font, (screen_width // 2, screen_height // 2 + 100), 200, 50, white, black, white)

            # Displays the version number in the bottom-right corner.
            draw_text("Version 30.0", game_font, white, screen, screen_width - 80, screen_height - 20)
            pygame.display.update() # Updates the screen.

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit() # Quits the game.
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if start_button_rect.collidepoint(mouse_pos):
                        pygame.mixer.music.stop()  # Stops music.
                        username, player_color = get_user_settings() # Gets user settings.
                        game_loop(username, player_color) # Starts the game.
                    elif settings_button_rect.collidepoint(mouse_pos):
                        pygame.mixer.music.stop()
                        settings_menu() # Opens settings menu.
                    elif score_history_button_rect.collidepoint(mouse_pos):
                        pygame.mixer.music.stop()
                        score_history_menu() # Opens score history.
                    elif quit_button_rect.collidepoint(mouse_pos):
                        pygame.quit()
                        sys.exit() # Exits the game.

            clock.tick(60) # Limits to 60 FPS.

    # ---------------- Function: Game Loop ----------------
    def game_loop(username, player_color):
        
        # Set initial player position in the center of the arena
        player_pos = [arena_width // 2, arena_height // 2]
        player_radius = 20 # Initial size of the player
        player_speed = 8 # Player movement speed
        score = 0  # Initial score is 0
        
        # Food settings
        food_count = 200
        food_radius = 5
        food_list = []
        
        # Generate food items at random positions
        for i in range(food_count):
            x = random.randint(0, arena_width)
            y = random.randint(0, arena_height)
            food_list.append([x, y])
            
        # Bot settings
        bot_count = 1
        bots = []
        for i in range(bot_count):
            bot_x = random.randint(0, arena_width)
            bot_y = random.randint(0, arena_height)
            bot_radius = random.randint(40, 100)
            bot_speed = random.uniform(1.5, 4)
            bot_color = (random.randint(0,255), random.randint(0,255), random.randint(0,255))
            bots.append({
                "x": bot_x,
                "y": bot_y,
                "radius": bot_radius,
                "speed": bot_speed,
                "behavior": "aggressive",
                "color": bot_color
            })
            
        # Initialize the snake enemy
        snake = initialize_snake(player_pos)
        
        # Star settings (collectibles that end the game)
        star_count = 5
        stars = []
        for i in range(star_count):
            star_x = random.randint(0, arena_width)
            star_y = random.randint(0, arena_height)
            stars.append((star_x, star_y))
        star_outer_radius = 45
        star_inner_radius = 21
        
        # Camera follows the player
        camera_x = player_pos[0] - screen_width // 2
        camera_y = player_pos[1] - screen_height // 2
        
        # Create a clock to control the frame rate
        clock = pygame.time.Clock()
        
        # ---------------- Game Loop Starts ----------------
        while True:
            screen.fill(black)  # Clear the screen with black background
            
            # Handle events like quit or pause
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    selection = pause_menu()
                    if selection == "main_menu":
                        menu()
                        return
                    elif selection == "quit":
                        pygame.quit(); sys.exit()
                        
            # Player movement input
            keys = pygame.key.get_pressed()
            dx = dy = 0
            if keys[controls_settings["up"]]:
                dy -= player_speed
            if keys[controls_settings["down"]]:
                dy += player_speed
            if keys[controls_settings["left"]]:
                dx -= player_speed
            if keys[controls_settings["right"]]:
                dx += player_speed
                
            # Update player position
            player_pos[0] += dx
            player_pos[1] += dy
            
            # Prevent player from going outside the arena
            player_pos[0] = max(player_radius, min(arena_width - player_radius, player_pos[0]))
            player_pos[1] = max(player_radius, min(arena_height - player_radius, player_pos[1]))
            
            # Update camera position based on player
            camera_x = player_pos[0] - screen_width // 2
            camera_y = player_pos[1] - screen_height // 2
            
            # ----------- Draw and Handle Food -----------
            for food in food_list:
                pygame.draw.circle(screen, yellow, (food[0] - camera_x, food[1] - camera_y), food_radius)
            new_food_list = []
            for food in food_list:
                if distance(player_pos, food) < player_radius + food_radius:
                    player_radius += 1
                    score += 1
                else:
                    new_food_list.append(food)
            food_list = new_food_list
            
            # ----------- Draw and Handle Bots -----------
            for bot in bots[:]:
                pygame.draw.circle(screen, bot["color"], (int(bot["x"]) - camera_x, int(bot["y"]) - camera_y), bot["radius"])
                if bot["behavior"] == "aggressive":
                    move_bot_towards_player(bot, player_pos)
                    
                # Make sure bot stays within arena
                bot["x"] = max(bot["radius"], min(arena_width - bot["radius"], bot["x"]))
                bot["y"] = max(bot["radius"], min(arena_height - bot["radius"], bot["y"]))
                
                # Collision detection with player
                if distance(player_pos, (bot["x"], bot["y"])) < player_radius + bot["radius"]:
                    if player_radius > bot["radius"]:
                        player_radius -= bot["radius"] // 2  # Shrink player after eating the bot
                        score += 50  # Earn 50 points for defeating a bot
                        bots.remove(bot) # Remove defeated bot
                        
                        # Spawn a new bot with random stats
                        new_bot_radius = random.randint(player_radius + 1, player_radius + 50)
                        new_bot_x = random.randint(0, arena_width)
                        new_bot_y = random.randint(0, arena_height)
                        new_bot_speed = random.uniform(1.5, 4)
                        new_bot_color = (random.randint(0,255), random.randint(0,255), random.randint(0,255))
                        bots.append({
                            "x": new_bot_x,
                            "y": new_bot_y,
                            "radius": new_bot_radius,
                            "speed": new_bot_speed,
                            "behavior": "aggressive",
                            "color": new_bot_color
                        })
                    else:
                        
                        # Player is eaten by bot → game over
                        save_score(username, score)
                        game_over_menu(username, player_color, score)
                        return

            # ----------- Handle Snake Collision -----------
            snake = update_snake(snake, player_pos)
            draw_snake(snake, camera_x, camera_y)
            if distance(snake["segments"][0], player_pos) < (player_radius + snake["segment_size"]):
                save_score(username, score)
                game_over_menu(username, player_color, score)
                return
            
            # ----------- Draw and Handle Stars -----------
            for star in stars:
                star_screen = (int(star[0]-camera_x), int(star[1]-camera_y))
                draw_star(screen, star_color, star_screen, star_outer_radius, star_inner_radius)
                if distance(player_pos, star) < (player_radius + star_outer_radius):
                    save_score(username, score)
                    game_over_menu(username, player_color, score)
                    return
                
            # Draw the player
            pygame.draw.circle(screen, player_color, (player_pos[0] - camera_x, player_pos[1] - camera_y), player_radius)
            
            # Draw username above the player
            draw_text(username, game_font, white, screen, player_pos[0] - camera_x, player_pos[1] - camera_y - player_radius - 20)
            
            # Draw score at top-left
            draw_text("Score: " + str(score), game_font, white, screen, 100, 30)
            
            # Update display
            pygame.display.update()
            clock.tick(60)

    # ---------------- Draw Star Function ----------------
    def draw_star(surface, color, center, outer_radius, inner_radius):
        cx, cy = center
        points = []
        for i in range(10):
            angle = math.radians(i * 36 - 90) # 36° step, starting from top (-90°)
            r = outer_radius if i % 2 == 0 else inner_radius
            x = cx + r * math.cos(angle)
            y = cy + r * math.sin(angle)
            points.append((x, y))
        pygame.draw.polygon(surface, color, points)

    # ---------------- Snake Enemy Functions ----------------
    
    # Initializes the snake enemy with a starting position and certain attributes.
    def initialize_snake(player_pos):
        snake = {
            "segments": [], # List of segments representing the snake's body.
            "speed": 3, # Speed at which the snake moves.
            "segment_size": 20, # Size of each segment of the snake.
            "detection_range": 300, # Range within which the snake will detect the player.
            "length": 15 # Initial length of the snake.
        }
        snake_x = random.randint(0, arena_width) # Randomly choose x-coordinate for the snake.
        snake_y = random.randint(0, arena_height) # Randomly choose y-coordinate for the snake.
        
        # Ensure the snake is far enough from the player.
        while distance((snake_x, snake_y), player_pos) < 400:
            snake_x = random.randint(0, arena_width)
            snake_y = random.randint(0, arena_height)
        segment_spacing = 25 # Distance between segments.
        
        # Create snake's body segments starting from the head.
        snake["segments"] = [(snake_x - i * segment_spacing, snake_y) for i in range(snake["length"])]
        return snake
    
    # Updates the snake's position based on the player's position.
    def update_snake(snake, player_pos):
        head = snake["segments"][0] # Get the snake's head.
        
        # If the snake is within its detection range of the player, it will move towards the player.
        if distance(head, player_pos) < snake["detection_range"]:
            angle = math.atan2(player_pos[1]-head[1], player_pos[0]-head[0]) # Calculate angle towards player.
            new_head = (head[0] + snake["speed"]*math.cos(angle), # Move the head.
                        head[1] + snake["speed"]*math.sin(angle))
            snake["segments"][0] = new_head # Update head position.
            segment_spacing = 25 # Distance between segments.
            
            # Update the positions of all body segments to follow the head.
            for i in range(1, len(snake["segments"])):
                prev_seg = snake["segments"][i-1] # Previous segment.
                curr_seg = snake["segments"][i] # Current segment.
                dx = prev_seg[0] - curr_seg[0] # Change in x position.
                dy = prev_seg[1] - curr_seg[1] # Change in y position.
                dist_val = math.sqrt(dx*dx + dy*dy) # Distance between the two segments.
                if dist_val != 0: # Avoid division by zero.
                    new_pos = (prev_seg[0] - (dx/dist_val)*segment_spacing,
                            prev_seg[1] - (dy/dist_val)*segment_spacing)
                    snake["segments"][i] = new_pos # Update the current segment position.
        return snake
    
    # Draws the snake on the screen.
    def draw_snake(snake, camera_x, camera_y):
        snake_color = (34, 139, 34)  # The color of the snake (forest green).
        head = snake["segments"][0] # Get the head segment of the snake.
        head_screen = (int(head[0]-camera_x), int(head[1]-camera_y)) # Adjust for camera position.
        pygame.draw.circle(screen, snake_color, head_screen, snake["segment_size"]) # Draw the head.
        
        # Eyes
        # Draw eyes on the snake's head.
        eye_radius = 3 # Size of the eyes.
        eye_offset_x = snake["segment_size"]//2 - eye_radius # X offset for eye placement.
        eye_offset_y = -snake["segment_size"]//3 # Y offset for eye placement.
        left_eye = (head_screen[0]-eye_offset_x, head_screen[1]+eye_offset_y) # Left eye position.
        right_eye = (head_screen[0]+eye_offset_x, head_screen[1]+eye_offset_y) # Right eye position.
        pygame.draw.circle(screen, white, left_eye, eye_radius) # Draw left eye.
        pygame.draw.circle(screen, white, right_eye, eye_radius) # Draw right eye.
        
        # Smiling mouth
        # Draw a smiling mouth.
        mouth_rect = pygame.Rect(0, 0, snake["segment_size"]*1.2, snake["segment_size"]*1.2) # Mouth size.
        mouth_rect.center = head_screen # Set mouth position at the head center.
        start_arc = math.radians(210) # Start angle for the arc.
        end_arc = math.radians(330) # End angle for the arc.
        pygame.draw.arc(screen, white, mouth_rect, start_arc, end_arc, 2) # Draw the smile.
        
        # Draw the body segments of the snake (excluding the head).
        for seg in snake["segments"][1:]:
            pos = (int(seg[0]-camera_x), int(seg[1]-camera_y))
            pygame.draw.circle(screen, snake_color, pos, snake["segment_size"])

    # ---------------- Program Start ----------------
    menu() # Start the game by displaying the menu.

# If interpreter cannot detect, It will say error message.
except Exception as e:
    print("Code gives error and interpreter cannot detect.")